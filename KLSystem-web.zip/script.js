const STORAGE_KEYS = {
  clients: 'klsystem_clients',
  quickIncome: 'klsystem_quick_income',
  services: 'klsystem_services',
  expenses: 'klsystem_expenses',
  inventory: 'klsystem_inventory',
  invoiceNumber: 'klsystem_invoice_number',
  settings: 'klsystem_settings',
  auth: 'klsystem_auth',
  users: 'klsystem_users'
};

const USER_SCOPED_KEYS = [
  STORAGE_KEYS.clients,
  STORAGE_KEYS.quickIncome,
  STORAGE_KEYS.services,
  STORAGE_KEYS.expenses,
  STORAGE_KEYS.inventory,
  STORAGE_KEYS.invoiceNumber,
  STORAGE_KEYS.settings
];

const defaultServices = [
  { id: createId(), name: 'Lavado', price: 350 },
  { id: createId(), name: 'Secado', price: 500 },
  { id: createId(), name: 'Uñas', price: 900 },
  { id: createId(), name: 'Tinte', price: 1800 },
  { id: createId(), name: 'Peinado', price: 750 },
  { id: createId(), name: 'Cejas', price: 300 }
];

let clients = loadData(STORAGE_KEYS.clients, []);
let quickIncome = loadData(STORAGE_KEYS.quickIncome, []);
let services = loadData(STORAGE_KEYS.services, defaultServices);
let expenses = loadData(STORAGE_KEYS.expenses, []);
let inventory = loadData(STORAGE_KEYS.inventory, []);
let settings = loadData(STORAGE_KEYS.settings, defaultSettings());
let auth = loadData(STORAGE_KEYS.auth, null);
let users = loadData(STORAGE_KEYS.users, []);
users = migrateUsers(users, auth);
ensureUserWorkspaces();
let currentInvoice = null;

sessionStorage.removeItem('klsystem_logged_in');
sessionStorage.removeItem('klsystem_active_user');

function defaultSettings() {
  return {
  salonName: 'KLSystem',
  moneyGoal: 6000,
  backgroundColor: '#f5f7fb',
  sidebarColor: '#111827'
  };
}

const money = new Intl.NumberFormat('es-DO', {
  style: 'currency',
  currency: 'DOP'
});

const today = new Date().toISOString().slice(0, 10);
const currentMonth = today.slice(0, 7);

document.addEventListener('DOMContentLoaded', () => {
  setDefaultDates();
  bindNavigation();
  bindForms();
  bindAuth();
  registerServiceWorker();
  renderAll();
  updateAuthState();
});

function loadData(key, fallback) {
  const saved = localStorage.getItem(dataKey(key));
  if (!saved) {
    saveData(key, fallback);
    return fallback;
  }

  try {
    return JSON.parse(saved);
  } catch {
    return fallback;
  }
}

function saveData(key, value) {
  localStorage.setItem(dataKey(key), JSON.stringify(value));
}

function setDefaultDates() {
  document.getElementById('currentDate').textContent = new Date().toLocaleDateString('es-DO', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  document.getElementById('clientDate').value = today;
  document.getElementById('quickIncomeDate').value = today;
  document.getElementById('expenseDate').value = today;
  document.getElementById('invoiceDate').textContent = new Date().toLocaleDateString('es-DO');
}

function bindNavigation() {
  document.querySelectorAll('.nav-btn').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.nav-btn').forEach((btn) => btn.classList.remove('active'));
      document.querySelectorAll('.section').forEach((section) => section.classList.remove('active'));

      button.classList.add('active');
      document.getElementById(button.dataset.section).classList.add('active');
      document.getElementById('pageTitle').textContent = button.textContent;
    });
  });
}

function bindForms() {
  document.getElementById('clientForm').addEventListener('submit', saveClient);
  document.getElementById('quickIncomeForm').addEventListener('submit', saveQuickIncome);
  document.getElementById('cancelQuickIncomeEdit').addEventListener('click', resetQuickIncomeForm);
  document.getElementById('serviceForm').addEventListener('submit', saveService);
  document.getElementById('cancelServiceEdit').addEventListener('click', resetServiceForm);
  document.getElementById('expenseForm').addEventListener('submit', saveExpense);
  document.getElementById('inventoryForm').addEventListener('submit', saveInventoryProduct);
  document.getElementById('invoiceForm').addEventListener('submit', generateInvoice);
  document.getElementById('printInvoice').addEventListener('click', () => window.print());
  document.getElementById('settingsForm').addEventListener('submit', saveSettings);
  document.getElementById('accountForm').addEventListener('submit', saveAccount);
  document.getElementById('newUserForm').addEventListener('submit', saveNewUser);
  document.getElementById('changeProfilePhoto').addEventListener('click', () => {
    document.getElementById('quickProfilePhoto').click();
  });
  document.getElementById('quickProfilePhoto').addEventListener('change', changeProfilePhoto);
}

function bindAuth() {
  document.getElementById('setupForm').addEventListener('submit', createAccount);
  document.getElementById('loginForm').addEventListener('submit', login);
  document.getElementById('recoveryForm').addEventListener('submit', recoverAccount);
  document.getElementById('showSetup').addEventListener('click', showSetupForm);
  document.getElementById('showRecovery').addEventListener('click', showRecoveryForm);
  document.getElementById('backToLogin').addEventListener('click', showLoginForm);
  document.getElementById('backToLoginFromSetup').addEventListener('click', showLoginForm);
  document.getElementById('logoutButton').addEventListener('click', logout);
}

function saveClient(event) {
  event.preventDefault();
  clients.unshift({
    id: createId(),
    name: value('clientName'),
    service: value('clientService'),
    price: numberValue('clientPrice'),
    date: value('clientDate'),
    payment: value('clientPayment')
  });
  saveData(STORAGE_KEYS.clients, clients);
  event.target.reset();
  document.getElementById('clientDate').value = today;
  renderAll();
}

function saveQuickIncome(event) {
  event.preventDefault();
  const id = value('quickIncomeId');
  const incomeData = {
    id: id || createId(),
    amount: numberValue('quickIncomeAmount'),
    date: value('quickIncomeDate')
  };

  if (id) {
    quickIncome = quickIncome.map((income) => income.id === id ? incomeData : income);
  } else {
    quickIncome.unshift(incomeData);
  }

  saveData(STORAGE_KEYS.quickIncome, quickIncome);
  resetQuickIncomeForm();
  renderAll();
}

function editQuickIncome(id) {
  const income = quickIncome.find((item) => item.id === id);
  if (!income) return;

  document.getElementById('quickIncomeId').value = income.id;
  document.getElementById('quickIncomeAmount').value = income.amount;
  document.getElementById('quickIncomeDate').value = income.date;
  document.getElementById('quickIncomeSubmit').textContent = 'Guardar cambios';
  document.getElementById('cancelQuickIncomeEdit').classList.remove('hidden');
}

function resetQuickIncomeForm() {
  document.getElementById('quickIncomeForm').reset();
  document.getElementById('quickIncomeId').value = '';
  document.getElementById('quickIncomeDate').value = today;
  document.getElementById('quickIncomeSubmit').textContent = 'Registrar dinero';
  document.getElementById('cancelQuickIncomeEdit').classList.add('hidden');
}

function saveService(event) {
  event.preventDefault();
  const id = value('serviceId');
  const data = {
    id: id || createId(),
    name: value('serviceName'),
    price: numberValue('servicePrice')
  };

  if (id) {
    services = services.map((service) => service.id === id ? data : service);
  } else {
    services.unshift(data);
  }

  saveData(STORAGE_KEYS.services, services);
  resetServiceForm();
  renderAll();
}

function editService(id) {
  const service = services.find((item) => item.id === id);
  if (!service) return;

  document.getElementById('serviceId').value = service.id;
  document.getElementById('serviceName').value = service.name;
  document.getElementById('servicePrice').value = service.price;
  document.getElementById('serviceSubmit').textContent = 'Guardar cambios';
  document.getElementById('cancelServiceEdit').classList.remove('hidden');
}

function resetServiceForm() {
  document.getElementById('serviceForm').reset();
  document.getElementById('serviceId').value = '';
  document.getElementById('serviceSubmit').textContent = 'Agregar servicio';
  document.getElementById('cancelServiceEdit').classList.add('hidden');
}

function deleteService(id) {
  services = services.filter((service) => service.id !== id);
  saveData(STORAGE_KEYS.services, services);
  renderAll();
}

function saveExpense(event) {
  event.preventDefault();
  expenses.unshift({
    id: createId(),
    product: value('expenseProduct'),
    cost: numberValue('expenseCost'),
    quantity: numberValue('expenseQuantity'),
    date: value('expenseDate'),
    provider: value('expenseProvider')
  });
  saveData(STORAGE_KEYS.expenses, expenses);
  event.target.reset();
  document.getElementById('expenseDate').value = today;
  renderAll();
}

function saveInventoryProduct(event) {
  event.preventDefault();
  inventory.unshift({
    id: createId(),
    name: value('inventoryName'),
    quantity: numberValue('inventoryQuantity'),
    buyPrice: numberValue('inventoryBuy'),
    sellPrice: numberValue('inventorySell')
  });
  saveData(STORAGE_KEYS.inventory, inventory);
  event.target.reset();
  renderAll();
}

function saveSettings(event) {
  event.preventDefault();
  settings = {
    salonName: value('salonName') || 'KLSystem',
    moneyGoal: Math.max(numberValue('moneyGoal'), 1),
    backgroundColor: value('backgroundColor') || '#f5f7fb',
    sidebarColor: value('sidebarColor') || '#111827'
  };
  saveData(STORAGE_KEYS.settings, settings);
  renderAll();
}

async function createAccount(event) {
  event.preventDefault();
  const email = value('setupEmail');
  const userName = value('setupUser');

  if (users.some((item) => item.email === email || item.user === userName)) {
    alert('Ese correo o usuario ya existe.');
    return;
  }

  const photo = await readPhoto('setupPhoto');
  const user = {
    id: createId(),
    email,
    user: userName,
    passwordHash: hashPassword(value('setupPassword')),
    photo: photo || ''
  };
  users.push(user);
  saveData(STORAGE_KEYS.users, users);
  initializeUserWorkspace(user.id);
  sessionStorage.setItem('klsystem_active_user', user.id);
  sessionStorage.setItem('klsystem_logged_in', 'true');
  loadUserWorkspace(user.id);
  event.target.reset();
  renderAll();
  updateAuthState();
}

function login(event) {
  event.preventDefault();
  if (!users.length) {
    text('loginMessage', 'No hay cuentas guardadas en este dispositivo. Crea una cuenta primero.');
    return;
  }

  const loginName = value('loginUser');
  const foundUser = users.find((item) => loginName === item.user || loginName === item.email);
  const isValidPassword = foundUser && hashPassword(value('loginPassword')) === foundUser.passwordHash;

  if (!foundUser || !isValidPassword) {
    text('loginMessage', 'Usuario o contraseña incorrectos.');
    return;
  }

  sessionStorage.setItem('klsystem_active_user', foundUser.id);
  sessionStorage.setItem('klsystem_logged_in', 'true');
  loadUserWorkspace(foundUser.id);
  document.getElementById('loginForm').reset();
  text('loginMessage', '');
  renderAll();
  updateAuthState();
}

function logout() {
  sessionStorage.removeItem('klsystem_logged_in');
  sessionStorage.removeItem('klsystem_active_user');
  updateAuthState();
}

function showRecoveryForm() {
  document.getElementById('loginForm').classList.add('hidden');
  document.getElementById('setupForm').classList.add('hidden');
  document.getElementById('recoveryForm').classList.remove('hidden');
  text('recoveryMessage', '');
  document.getElementById('recoveryEmail').focus();
}

function showSetupForm() {
  document.getElementById('loginForm').classList.add('hidden');
  document.getElementById('recoveryForm').classList.add('hidden');
  document.getElementById('setupForm').classList.remove('hidden');
  document.getElementById('setupEmail').focus();
}

function showLoginForm() {
  document.getElementById('recoveryForm').classList.add('hidden');
  document.getElementById('setupForm').classList.add('hidden');
  document.getElementById('loginForm').classList.remove('hidden');
  document.getElementById('recoveryForm').reset();
  document.getElementById('setupForm').reset();
  text('recoveryMessage', '');
  text('loginMessage', '');
}

function recoverAccount(event) {
  event.preventDefault();
  const foundUser = users.find((item) => item.email === value('recoveryEmail'));

  if (!foundUser) {
    text('recoveryMessage', 'Ese correo no coincide con la cuenta guardada.');
    return;
  }

  const newUser = value('recoveryUser') || foundUser.user;
  const newPassword = value('recoveryPassword');

  if (users.some((item) => item.id !== foundUser.id && item.user === newUser)) {
    text('recoveryMessage', 'Ese usuario ya pertenece a otra cuenta.');
    return;
  }

  if (!newPassword) {
    document.getElementById('recoveryUser').value = foundUser.user;
    text('recoveryMessage', `Usuario encontrado: ${foundUser.user}. Escribe una nueva contraseña.`);
    return;
  }

  users = users.map((item) => item.id === foundUser.id ? {
    ...item,
    user: newUser,
    passwordHash: hashPassword(newPassword)
  } : item);
  saveData(STORAGE_KEYS.users, users);
  showLoginForm();
  document.getElementById('loginUser').value = newUser;
  text('loginMessage', 'Acceso recuperado. Entra con tu nueva contraseña.');
  renderAll();
}

async function saveAccount(event) {
  event.preventDefault();
  const activeUser = getActiveUser();
  if (!activeUser) return;
  const email = value('accountEmail');
  const userName = value('accountUser');

  if (users.some((item) => item.id !== activeUser.id && (item.email === email || item.user === userName))) {
    alert('Ese correo o usuario ya pertenece a otra cuenta.');
    return;
  }

  const photo = await readPhoto('accountPhoto');
  const updatedUser = {
    ...activeUser,
    email,
    user: userName,
    passwordHash: value('accountPassword') ? hashPassword(value('accountPassword')) : activeUser.passwordHash,
    photo: photo || activeUser.photo || ''
  };
  users = users.map((item) => item.id === activeUser.id ? updatedUser : item);
  saveData(STORAGE_KEYS.users, users);
  document.getElementById('accountPassword').value = '';
  document.getElementById('accountPhoto').value = '';
  renderAll();
}

async function saveNewUser(event) {
  event.preventDefault();
  const email = value('newUserEmail');
  const userName = value('newUserName');

  if (users.some((item) => item.email === email || item.user === userName)) {
    alert('Ese correo o usuario ya existe.');
    return;
  }

  const photo = await readPhoto('newUserPhoto');
  users.push({
    id: createId(),
    email,
    user: userName,
    passwordHash: hashPassword(value('newUserPassword')),
    photo: photo || ''
  });
  initializeUserWorkspace(users[users.length - 1].id);
  saveData(STORAGE_KEYS.users, users);
  event.target.reset();
  renderAll();
}

async function changeProfilePhoto() {
  const photo = await readPhoto('quickProfilePhoto');
  const activeUser = getActiveUser();
  if (!photo || !activeUser) return;

  users = users.map((item) => item.id === activeUser.id ? {
    ...item,
    photo
  } : item);
  saveData(STORAGE_KEYS.users, users);
  document.getElementById('quickProfilePhoto').value = '';
  renderAll();
}

function generateInvoice(event) {
  event.preventDefault();
  const selectedIds = Array.from(document.getElementById('invoiceServices').selectedOptions).map((option) => option.value);
  const selectedServices = services.filter((service) => selectedIds.includes(service.id));
  const invoiceNumber = Number(localStorage.getItem(dataKey(STORAGE_KEYS.invoiceNumber)) || 1);

  currentInvoice = {
    number: invoiceNumber,
    client: value('invoiceClient'),
    date: new Date().toLocaleDateString('es-DO'),
    items: selectedServices,
    total: selectedServices.reduce((sum, service) => sum + service.price, 0)
  };

  localStorage.setItem(dataKey(STORAGE_KEYS.invoiceNumber), String(invoiceNumber + 1));
  renderInvoice();
}

function deleteItem(collection, id) {
  if (collection === 'clients') {
    clients = clients.filter((item) => item.id !== id);
    saveData(STORAGE_KEYS.clients, clients);
  }

  if (collection === 'quickIncome') {
    quickIncome = quickIncome.filter((item) => item.id !== id);
    saveData(STORAGE_KEYS.quickIncome, quickIncome);
  }

  if (collection === 'expenses') {
    expenses = expenses.filter((item) => item.id !== id);
    saveData(STORAGE_KEYS.expenses, expenses);
  }

  if (collection === 'inventory') {
    inventory = inventory.filter((item) => item.id !== id);
    saveData(STORAGE_KEYS.inventory, inventory);
  }

  renderAll();
}

function renderAll() {
  renderSettings();
  renderUsers();
  renderDashboard();
  renderClients();
  renderQuickIncome();
  renderServices();
  renderExpenses();
  renderInventory();
  renderInvoiceOptions();
  renderReports();
  renderInvoice();
}

function renderDashboard() {
  const todayClients = clients.filter((client) => client.date === today);
  const todayQuickIncome = quickIncome.filter((income) => income.date === today);
  const todayRevenue = sum(todayClients, 'price') + sum(todayQuickIncome, 'amount');
  const totalInvested = expenses.reduce((sumTotal, item) => sumTotal + item.cost * item.quantity, 0);
  const totalRevenue = sum(clients, 'price') + sum(quickIncome, 'amount');
  const netProfit = totalRevenue - totalInvested;

  text('todayRevenue', money.format(todayRevenue));
  text('totalInvested', money.format(totalInvested));
  text('netProfit', money.format(netProfit));
  text('clientsToday', todayClients.length);

  const levelBar = document.getElementById('profitLevelBar');
  const levelText = document.getElementById('profitLevelText');
  const goal = Number(settings.moneyGoal) || 6000;
  const progress = Math.min((todayRevenue / goal) * 100, 100);
  levelBar.className = 'level-bar';

  if (progress < 40) {
    levelBar.classList.add('low');
    levelBar.style.width = `${Math.max(progress, 8)}%`;
    levelText.textContent = 'Flojas';
  } else if (progress < 80) {
    levelBar.classList.add('medium');
    levelBar.style.width = `${progress}%`;
    levelText.textContent = 'Normal';
  } else {
    levelBar.classList.add('high');
    levelBar.style.width = `${progress}%`;
    levelText.textContent = 'Buenas';
  }

  renderRows('recentClients', todayClients.slice(0, 6), (client) => `
    <tr>
      <td>${escapeHtml(client.name)}</td>
      <td>${escapeHtml(client.service)}</td>
      <td>${formatDate(client.date)}</td>
      <td>${escapeHtml(client.payment)}</td>
      <td>${money.format(client.price)}</td>
    </tr>
  `, 5);
}

function renderClients() {
  renderRows('clientsTable', clients, (client) => `
    <tr>
      <td>${escapeHtml(client.name)}</td>
      <td>${escapeHtml(client.service)}</td>
      <td>${formatDate(client.date)}</td>
      <td>${escapeHtml(client.payment)}</td>
      <td>${money.format(client.price)}</td>
      <td class="actions"><button class="danger-btn" onclick="deleteItem('clients', '${client.id}')">Eliminar</button></td>
    </tr>
  `, 6);
}

function renderQuickIncome() {
  renderRows('quickIncomeTable', quickIncome, (income) => `
    <tr>
      <td>${formatDate(income.date)}</td>
      <td>${money.format(income.amount)}</td>
      <td class="actions">
        <button class="edit-btn" onclick="editQuickIncome('${income.id}')">Editar</button>
        <button class="danger-btn" onclick="deleteItem('quickIncome', '${income.id}')">Eliminar</button>
      </td>
    </tr>
  `, 3);
}

function renderServices() {
  const list = document.getElementById('servicesList');
  if (!services.length) {
    list.innerHTML = '<p class="empty">No hay servicios registrados.</p>';
    return;
  }

  list.innerHTML = services.map((service) => `
    <article class="service-card">
      <div>
        <strong>${escapeHtml(service.name)}</strong>
        <span>${money.format(service.price)}</span>
      </div>
      <div>
        <button class="edit-btn" onclick="editService('${service.id}')">Editar</button>
        <button class="danger-btn" onclick="deleteService('${service.id}')">Eliminar</button>
      </div>
    </article>
  `).join('');
}

function renderExpenses() {
  renderRows('expensesTable', expenses, (expense) => `
    <tr>
      <td>${escapeHtml(expense.product)}</td>
      <td>${money.format(expense.cost)}</td>
      <td>${expense.quantity}</td>
      <td>${formatDate(expense.date)}</td>
      <td>${escapeHtml(expense.provider)}</td>
      <td class="actions"><button class="danger-btn" onclick="deleteItem('expenses', '${expense.id}')">Eliminar</button></td>
    </tr>
  `, 6);
}

function renderInventory() {
  renderRows('inventoryTable', inventory, (product) => {
    const low = product.quantity <= 3;
    return `
      <tr>
        <td>${escapeHtml(product.name)}</td>
        <td>${product.quantity}</td>
        <td>${money.format(product.buyPrice)}</td>
        <td>${money.format(product.sellPrice)}</td>
        <td><span class="${low ? 'low-stock' : 'ok-stock'}">${low ? 'Producto bajo' : 'Disponible'}</span></td>
        <td class="actions"><button class="danger-btn" onclick="deleteItem('inventory', '${product.id}')">Eliminar</button></td>
      </tr>
    `;
  }, 6);
}

function renderInvoiceOptions() {
  const select = document.getElementById('invoiceServices');
  select.innerHTML = services.map((service) => `
    <option value="${service.id}">${escapeHtml(service.name)} - ${money.format(service.price)}</option>
  `).join('');
}

function renderInvoice() {
  const nextNumber = Number(localStorage.getItem(dataKey(STORAGE_KEYS.invoiceNumber)) || 1);
  const invoice = currentInvoice || { number: nextNumber, client: 'Sin seleccionar', items: [], total: 0 };

  text('invoiceNumber', String(invoice.number).padStart(4, '0'));
  text('invoiceSalonName', settings.salonName);
  text('invoiceClientName', invoice.client);
  text('invoiceTotal', money.format(invoice.total));

  renderRows('invoiceItems', invoice.items, (item) => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>${money.format(item.price)}</td>
    </tr>
  `, 2);
}

function renderSettings() {
  const salonName = settings.salonName || 'KLSystem';
  const moneyGoal = Number(settings.moneyGoal) || 6000;
  const backgroundColor = settings.backgroundColor || '#f5f7fb';
  const sidebarColor = settings.sidebarColor || '#111827';
  const activeUser = getActiveUser();
  const initials = salonName
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0])
    .join('')
    .toUpperCase() || 'KL';

  text('sidebarSalonName', salonName);
  text('brandInitials', initials);
  text('currentSalonName', salonName);
  text('currentMoneyGoal', money.format(moneyGoal));
  text('currentBackgroundColor', backgroundColor);
  text('currentSidebarColor', sidebarColor);
  document.getElementById('salonName').value = salonName;
  document.getElementById('moneyGoal').value = moneyGoal;
  document.getElementById('backgroundColor').value = backgroundColor;
  document.getElementById('sidebarColor').value = sidebarColor;
  text('loginSalonName', salonName);
  text('loginBrandInitials', initials);
  applyThemeColors();

  if (activeUser) {
    text('profileUserName', activeUser.user);
    document.getElementById('accountEmail').value = activeUser.email || '';
    document.getElementById('accountUser').value = activeUser.user || '';
  }

  setProfileImage('profilePhotoPreview');
  setProfileImage('settingsProfilePhoto');
}

function renderUsers() {
  const list = document.getElementById('usersList');
  if (!list) return;

  if (!users.length) {
    list.innerHTML = '<p class="empty">No hay usuarios registrados.</p>';
    return;
  }

  const activeUser = getActiveUser();
  list.innerHTML = users.map((item) => `
    <article class="user-card">
      <div>
        <img src="${item.photo || defaultAvatar()}" alt="Perfil">
        <div>
          <strong>${escapeHtml(item.user)}${activeUser && activeUser.id === item.id ? ' (actual)' : ''}</strong>
          <span>${escapeHtml(item.email)}</span>
        </div>
      </div>
      <button class="danger-btn" onclick="deleteUser('${item.id}')" ${users.length === 1 ? 'disabled' : ''}>Eliminar</button>
    </article>
  `).join('');
}

function renderReports() {
  const dailyRevenue = sum(clients.filter((client) => client.date === today), 'price')
    + sum(quickIncome.filter((income) => income.date === today), 'amount');
  const monthlyRevenue = sum(clients.filter((client) => client.date.slice(0, 7) === currentMonth), 'price')
    + sum(quickIncome.filter((income) => income.date.slice(0, 7) === currentMonth), 'amount');
  const monthlyExpenses = expenses
    .filter((expense) => expense.date.slice(0, 7) === currentMonth)
    .reduce((total, expense) => total + expense.cost * expense.quantity, 0);
  const generalRevenue = sum(clients, 'price') + sum(quickIncome, 'amount');
  const generalExpenses = expenses.reduce((total, expense) => total + expense.cost * expense.quantity, 0);
  const generalBalance = generalRevenue - generalExpenses;

  text('dailyReport', money.format(dailyRevenue));
  text('monthlyRevenueReport', money.format(monthlyRevenue));
  text('monthlyExpensesReport', money.format(monthlyExpenses));
  text('generalBalanceReport', money.format(generalBalance));

  const max = Math.max(monthlyRevenue, monthlyExpenses, Math.abs(generalBalance), 1);
  document.getElementById('revenueBar').style.width = `${Math.min((monthlyRevenue / max) * 100, 100)}%`;
  document.getElementById('expenseBar').style.width = `${Math.min((monthlyExpenses / max) * 100, 100)}%`;
  document.getElementById('balanceBar').style.width = `${Math.min((Math.abs(generalBalance) / max) * 100, 100)}%`;
}

function renderRows(targetId, items, template, colspan) {
  const target = document.getElementById(targetId);
  if (!items.length) {
    target.innerHTML = `<tr><td colspan="${colspan}" class="empty">No hay datos registrados.</td></tr>`;
    return;
  }
  target.innerHTML = items.map(template).join('');
}

function value(id) {
  return document.getElementById(id).value.trim();
}

function numberValue(id) {
  return Number(document.getElementById(id).value) || 0;
}

function text(id, content) {
  document.getElementById(id).textContent = content;
}

function sum(items, property) {
  return items.reduce((total, item) => total + Number(item[property] || 0), 0);
}

function formatDate(date) {
  if (!date) return '';
  const [year, month, day] = date.split('-');
  return `${day}/${month}/${year}`;
}

function escapeHtml(textValue) {
  return String(textValue)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function createId() {
  return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function updateAuthState() {
  const loggedIn = sessionStorage.getItem('klsystem_logged_in') === 'true' && Boolean(getActiveUser());
  const hasUsers = users.length > 0;
  document.body.classList.toggle('auth-locked', !loggedIn);
  document.getElementById('setupForm').classList.toggle('hidden', hasUsers);
  document.getElementById('loginForm').classList.toggle('hidden', !hasUsers);
  document.getElementById('recoveryForm').classList.add('hidden');
  text('loginMessage', '');
  text('recoveryMessage', '');
}

function migrateUsers(savedUsers, oldAuth) {
  if (savedUsers.length || !oldAuth) return savedUsers;

  const userId = createId();
  const migratedUsers = [{
    id: userId,
    email: oldAuth.email || '',
    user: oldAuth.user || 'usuario',
    passwordHash: oldAuth.passwordHash || '',
    photo: oldAuth.photo || ''
  }];
  copyLegacyWorkspace(userId);
  saveData(STORAGE_KEYS.users, migratedUsers);
  return migratedUsers;
}

function ensureUserWorkspaces() {
  users.forEach((user, index) => {
    if (index === 0 && !localStorage.getItem(scopedKey(user.id, STORAGE_KEYS.settings))) {
      copyLegacyWorkspace(user.id);
    }
    initializeUserWorkspace(user.id);
  });
}

function dataKey(key) {
  const activeId = sessionStorage.getItem('klsystem_active_user');
  if (activeId && USER_SCOPED_KEYS.includes(key)) {
    return scopedKey(activeId, key);
  }
  return key;
}

function scopedKey(userId, key) {
  return `${key}_${userId}`;
}

function initializeUserWorkspace(userId) {
  const defaults = {
    [STORAGE_KEYS.clients]: [],
    [STORAGE_KEYS.quickIncome]: [],
    [STORAGE_KEYS.services]: defaultServices.map((service) => ({ ...service, id: createId() })),
    [STORAGE_KEYS.expenses]: [],
    [STORAGE_KEYS.inventory]: [],
    [STORAGE_KEYS.settings]: defaultSettings()
  };

  Object.entries(defaults).forEach(([key, value]) => {
    const userKey = scopedKey(userId, key);
    if (!localStorage.getItem(userKey)) {
      localStorage.setItem(userKey, JSON.stringify(value));
    }
  });

  if (!localStorage.getItem(scopedKey(userId, STORAGE_KEYS.invoiceNumber))) {
    localStorage.setItem(scopedKey(userId, STORAGE_KEYS.invoiceNumber), '1');
  }
}

function copyLegacyWorkspace(userId) {
  const keysToCopy = [
    STORAGE_KEYS.clients,
    STORAGE_KEYS.quickIncome,
    STORAGE_KEYS.services,
    STORAGE_KEYS.expenses,
    STORAGE_KEYS.inventory,
    STORAGE_KEYS.settings
  ];

  keysToCopy.forEach((key) => {
    const legacyValue = localStorage.getItem(key);
    if (legacyValue && !localStorage.getItem(scopedKey(userId, key))) {
      localStorage.setItem(scopedKey(userId, key), legacyValue);
    }
  });

  const legacyInvoice = localStorage.getItem(STORAGE_KEYS.invoiceNumber);
  if (legacyInvoice && !localStorage.getItem(scopedKey(userId, STORAGE_KEYS.invoiceNumber))) {
    localStorage.setItem(scopedKey(userId, STORAGE_KEYS.invoiceNumber), legacyInvoice);
  }
}

function loadUserWorkspace(userId) {
  sessionStorage.setItem('klsystem_active_user', userId);
  initializeUserWorkspace(userId);
  clients = loadData(STORAGE_KEYS.clients, []);
  quickIncome = loadData(STORAGE_KEYS.quickIncome, []);
  services = loadData(STORAGE_KEYS.services, defaultServices);
  expenses = loadData(STORAGE_KEYS.expenses, []);
  inventory = loadData(STORAGE_KEYS.inventory, []);
  settings = loadData(STORAGE_KEYS.settings, defaultSettings());
  currentInvoice = null;
}

function getActiveUser() {
  const activeId = sessionStorage.getItem('klsystem_active_user');
  return users.find((item) => item.id === activeId) || users[0] || null;
}

function deleteUser(id) {
  if (users.length <= 1) return;

  users = users.filter((item) => item.id !== id);
  saveData(STORAGE_KEYS.users, users);

  if (sessionStorage.getItem('klsystem_active_user') === id) {
    logout();
    return;
  }

  renderAll();
}

function applyThemeColors() {
  document.documentElement.style.setProperty('--bg', settings.backgroundColor || '#f5f7fb');
  document.documentElement.style.setProperty('--sidebar-bg', settings.sidebarColor || '#111827');
}

function hashPassword(password) {
  let hash = 0;
  for (let index = 0; index < password.length; index += 1) {
    hash = ((hash << 5) - hash) + password.charCodeAt(index);
    hash |= 0;
  }
  return String(hash);
}

function readPhoto(inputId) {
  const file = document.getElementById(inputId).files[0];
  if (!file) return Promise.resolve('');

  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => resolve('');
    reader.readAsDataURL(file);
  });
}

function setProfileImage(imageId) {
  const image = document.getElementById(imageId);
  if (!image) return;
  const activeUser = getActiveUser();
  image.src = activeUser && activeUser.photo ? activeUser.photo : defaultAvatar();
}

function defaultAvatar() {
  return 'data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%2280%22%20height=%2280%22%20viewBox=%220%200%2080%2080%22%3E%3Crect%20width=%2280%22%20height=%2280%22%20rx=%2240%22%20fill=%22%23dfe5ef%22/%3E%3Ccircle%20cx=%2240%22%20cy=%2230%22%20r=%2214%22%20fill=%22%23687389%22/%3E%3Cpath%20d=%22M18%2068c4-15%2016-23%2022-23s18%208%2022%2023%22%20fill=%22%23687389%22/%3E%3C/svg%3E';
}

function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;

  navigator.serviceWorker.register('./sw.js').catch(() => {
    // The app still works online if the browser blocks offline caching.
  });
}
